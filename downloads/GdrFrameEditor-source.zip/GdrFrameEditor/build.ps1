$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    dotnet run --project GdrEditor.Tests -- samples/GRIEF.gdr2
    if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
    dotnet publish GdrEditor.WinForms -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true -p:DebugType=None -o artifacts/win-x64
    if ($LASTEXITCODE -ne 0) { throw 'Publish failed' }
    Copy-Item samples/GRIEF.gdr2 artifacts/win-x64/GRIEF.gdr2
    Copy-Item README.ko.md artifacts/win-x64/README.ko.md
    Write-Host 'Build complete: artifacts/win-x64/GdrFrameEditor.exe'
} finally { Pop-Location }
