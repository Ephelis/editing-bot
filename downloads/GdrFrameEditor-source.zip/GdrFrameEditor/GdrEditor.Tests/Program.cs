using GdrEditor.Core;

int passed=0;
void Test(string name,Action action){action();passed++;Console.WriteLine("PASS "+name);}
void Assert(bool ok){if(!ok)throw new Exception("Assertion failed");}
void Reject(Action action){try{action();}catch(Exception e)when(e is InvalidDataException or OverflowException or System.Text.DecoderFallbackException){return;}throw new Exception("Invalid input accepted");}
string sample=args.FirstOrDefault()??"samples/GRIEF.gdr2";
byte[] original=File.ReadAllBytes(sample);
var doc=Replay.Read(original);
Test("GRIEF metadata and event counts",()=>Assert(doc.Author=="ligkus" && doc.LevelName=="GRIEF" && doc.Framerate==480 && doc.Inputs.Count==1266 && doc.Inputs.Count(x=>!x.Player2)==1250));
Test("Unchanged GRIEF byte-exact roundtrip",()=>Assert(doc.Write().SequenceEqual(original)));
Test("Edit frame, player and state then reopen",()=>{
 var r=Replay.Read(original);var row=r.Inputs[0];row.Frame+=3;row.Player2=!row.Player2;row.Down=!row.Down;
 var next=Replay.Read(r.Write());Assert(next.Inputs.Any(x=>x.Frame==row.Frame && x.Player2==row.Player2 && x.Down==row.Down));Assert(next.Inputs.Count==1266);
});
Test("Batch shift and transactional underflow",()=>{
 var r=new Replay{Inputs=[new(){Frame=10},new(){Frame=20}]};r.Shift(r.Inputs,5);Assert(r.Inputs[0].Frame==15 && r.Inputs[1].Frame==25);
 Reject(()=>r.Shift(r.Inputs,-16));Assert(r.Inputs[0].Frame==15 && r.Inputs[1].Frame==25);
 Reject(()=>r.Shift(r.Inputs,long.MinValue));Assert(r.Inputs[0].Frame==15);
});
Test("Platformer, extensions, Unicode and death frames preserved",()=>{
 var r=new Replay{Platformer=true,Author="한글",InputTag="custom",Extension=[1,2,3],Deaths=[10,20],Seed=-42,Inputs=[new(){Frame=12,Button=2,Extension=[8,9]},new(){Frame=7,Button=3,Player2=true,Down=false,Extension=[3]}]};
 byte[] bytes=r.Write();var next=Replay.Read(bytes);Assert(next.Author=="한글" && next.Seed==-42 && next.Inputs[0].Button==3 && next.Deaths.SequenceEqual(r.Deaths) && next.Extension.SequenceEqual(r.Extension));Assert(next.Write().SequenceEqual(bytes));
});
Test("Empty and P2-only replay",()=>{Assert(Replay.Read(new Replay().Write()).Inputs.Count==0);var r=new Replay{Inputs=[new(){Frame=5,Player2=true}]};Assert(Replay.Read(r.Write()).Inputs[0].Frame==5);});
Test("Every truncated sample is rejected",()=>{for(int n=0;n<original.Length;n++)Reject(()=>Replay.Read(original[..n]));});
Test("Bad magic, version, trailing bytes and overflowing varint",()=>{
 var bad=(byte[])original.Clone();bad[0]=0;Reject(()=>Replay.Read(bad));bad=(byte[])original.Clone();bad[3]=3;Reject(()=>Replay.Read(bad));Reject(()=>Replay.Read([..original,0]));Reject(()=>Replay.Read([71,68,82,255,255,255,255,255,255,255,255,255,255]));
});
Test("Invalid FPS, duration and classic button rejected",()=>{
 var r=Replay.Read(original);r.Framerate=0;Reject(()=>r.Write());r.Framerate=double.NaN;Reject(()=>r.Write());r.Framerate=480;r.Duration=-1;Reject(()=>r.Write());r.Duration=0;r.Inputs[0].Button=2;Reject(()=>r.Write());
});
Test("Atomic save, overwrite backup and reopen",()=>{
 string dir=Path.Combine(Path.GetTempPath(),Guid.NewGuid().ToString());Directory.CreateDirectory(dir);
 try{string path=Path.Combine(dir,"test.gdr2");doc.SaveAs(path);Assert(File.ReadAllBytes(path).SequenceEqual(original));var r=Replay.Read(original);r.Author="edited";r.SaveAs(path);Assert(Replay.Read(File.ReadAllBytes(path)).Author=="edited");Assert(File.ReadAllBytes(Directory.GetFiles(dir,"*.bak").Single()).SequenceEqual(original));Assert(Directory.GetFiles(dir,"*.tmp").Length==0);}finally{Directory.Delete(dir,true);}
});
Console.WriteLine($"{passed} test groups passed.");

if(args.Length>1){var edited=Replay.Read(original);edited.Inputs[0].Frame+=1;edited.Inputs[0].Down=!edited.Inputs[0].Down;edited.SaveAs(args[1]);}
