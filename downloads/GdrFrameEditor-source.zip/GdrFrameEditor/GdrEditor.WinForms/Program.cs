using GdrEditor.Core;
using System.ComponentModel;
using System.Text.Json;

namespace GdrEditor;

internal static class Program
{
    [STAThread] static void Main(string[] args) {
        ApplicationConfiguration.Initialize();
        Application.Run(new EditorForm(args.FirstOrDefault()));
    }
}

public sealed class EditorForm : Form
{
    Replay? doc;
    string? filePath;
    string lastState = "", savedState = "";
    readonly Stack<string> undo = new(), redo = new();
    bool loading;
    readonly DataGridView grid = new() { Dock = DockStyle.Fill, AutoGenerateColumns = false, AllowUserToAddRows = false,
        AllowUserToDeleteRows = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = true,
        BackgroundColor = Color.White, BorderStyle = BorderStyle.None, RowHeadersWidth = 55, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
    readonly PropertyGrid properties = new() { Dock = DockStyle.Fill, ToolbarVisible = false, HelpVisible = true, PropertySort = PropertySort.NoSort };
    readonly ToolStripStatusLabel status = new() { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
    readonly NumericUpDown shift = new() { Minimum = -1000000000, Maximum = 1000000000, Value = 1, Width = 115 };
    readonly NumericUpDown seek = new() { Maximum = decimal.MaxValue, Width = 145 };
    readonly Timeline timeline = new() { Dock = DockStyle.Fill };
    public EditorForm(string? startup) {
        Text = "GDR2 프레임 편집기"; Width = 1180; Height = 800; MinimumSize = new(850,600);
        Font = new Font("맑은 고딕", 10); StartPosition = FormStartPosition.CenterScreen;
        var menu = new MenuStrip();
        var file = new ToolStripMenuItem("파일");
        file.DropDownItems.Add(Item("열기…", Keys.Control | Keys.O, Open));
        file.DropDownItems.Add(Item("다른 이름으로 저장…", Keys.Control | Keys.Shift | Keys.S, Save));
        var edit = new ToolStripMenuItem("편집");
        edit.DropDownItems.Add(Item("실행 취소", Keys.Control | Keys.Z, Undo));
        edit.DropDownItems.Add(Item("다시 실행", Keys.Control | Keys.Y, Redo));
        edit.DropDownItems.Add(Item("선택 삭제", Keys.Control | Keys.Delete, Delete));
        edit.DropDownItems.Add(Item("사망 프레임 편집…", Keys.None, EditDeaths));
        edit.DropDownItems.Add(Item("프레임 순으로 정렬", Keys.None, SortFrames));
        menu.Items.AddRange([file,edit]); MainMenuStrip = menu;
        var toolbar = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new(6), AutoSize = true, WrapContents = true };
        toolbar.Controls.AddRange([Button("열기",Open), Button("다른 이름으로 저장",Save), Button("입력 추가",Add), Button("선택 삭제",Delete),
            new Label { Text="프레임 이동",AutoSize=true,Margin=new(8,8,0,0)},shift,Button("선택에 적용",Shift),
            seek,Button("프레임 찾기",Seek)]);
        var split = new SplitContainer { Dock = DockStyle.Fill, Width = 1100, SplitterDistance = 270, FixedPanel = FixedPanel.Panel1 };
        split.Panel1.Controls.Add(properties); split.Panel2.Controls.Add(grid);
        grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName="Frame", HeaderText="프레임", Name="Frame", ValueType=typeof(ulong) });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name="Time", HeaderText="시간 (초)", ReadOnly=true });
        grid.Columns.Add(new DataGridViewComboBoxColumn { DataPropertyName="Button",Name="Button",HeaderText="버튼", DataSource=new[]{new Choice(0,"없음 (0)"),new Choice(1,"점프 (1)"),new Choice(2,"왼쪽 (2)"),new Choice(3,"오른쪽 (3)")},DisplayMember="Text",ValueMember="Id" });
        grid.Columns.Add(new DataGridViewCheckBoxColumn { DataPropertyName="Player2",HeaderText="플레이어 2",Name="Player2" });
        grid.Columns.Add(new DataGridViewCheckBoxColumn { DataPropertyName="Down",HeaderText="누름 (해제=뗌)",Name="Down" });
        grid.CellFormatting += (_,e) => { if (doc != null && e.RowIndex >= 0 && grid.Columns[e.ColumnIndex].Name == "Time")
            e.Value = (((ReplayInput)grid.Rows[e.RowIndex].DataBoundItem).Frame / doc.Framerate).ToString("F6"); };
        grid.CellValidating += (_,e) => {
            if (grid.Columns[e.ColumnIndex].Name == "Frame" && (!ulong.TryParse(Convert.ToString(e.FormattedValue),out var n) || n > (ulong.MaxValue >> 3))) {
                e.Cancel=true; grid.Rows[e.RowIndex].ErrorText="0 이상의 유효한 정수 프레임을 입력하세요.";
            }
        };
        grid.CellEndEdit += (_,e) => { grid.Rows[e.RowIndex].ErrorText=""; Record(); };
        grid.CurrentCellDirtyStateChanged += (_,_) => { if (grid.IsCurrentCellDirty && grid.CurrentCell is DataGridViewCheckBoxCell) grid.CommitEdit(DataGridViewDataErrorContexts.Commit); };
        grid.CellValueChanged += (_,_) => Record();
        grid.DataError += (_,e) => { e.ThrowException=false; status.Text="입력 값을 확인하세요. 프레임은 0 이상의 정수입니다."; };
        grid.SelectionChanged += (_,_) => { timeline.Selected = Selected().FirstOrDefault()?.Frame; timeline.Invalidate(); };
        properties.PropertyValueChanged += (_,_) => { Record(); grid.Invalidate(); };
        timeline.Jump += frame => GoTo(frame);
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount=3,ColumnCount=1 };
        layout.RowStyles.Add(new(SizeType.AutoSize)); layout.RowStyles.Add(new(SizeType.Percent,100));layout.RowStyles.Add(new(SizeType.Absolute,95));
        layout.Controls.Add(toolbar,0,0);layout.Controls.Add(split,0,1);layout.Controls.Add(timeline,0,2);
        var strip = new StatusStrip(); strip.Items.Add(status);
        Controls.Add(layout);Controls.Add(strip);Controls.Add(menu);
        AllowDrop=true;
        DragEnter += (_,e) => e.Effect=e.Data?.GetDataPresent(DataFormats.FileDrop)==true ? DragDropEffects.Copy : DragDropEffects.None;
        DragDrop += (_,e) => { if (e.Data?.GetData(DataFormats.FileDrop) is string[] paths && paths.Length>0 && MayDiscard()) LoadFile(paths[0]); };
        FormClosing += (_,e) => e.Cancel=!MayDiscard();
        Shown += (_,_) => {
            var path = startup ?? Path.Combine(AppContext.BaseDirectory,"GRIEF.gdr2");
            if (File.Exists(path)) LoadFile(path); else UpdateStatus();
        };
    }
    sealed record Choice(int Id,string Text);
    static Button Button(string text,Action action) { var b=new Button{Text=text,AutoSize=true,Height=32}; b.Click+=(_,_)=>action(); return b; }
    static ToolStripMenuItem Item(string text,Keys keys,Action action) { var i=new ToolStripMenuItem(text){ShortcutKeys=keys};i.Click+=(_,_)=>action();return i; }
    void Error(Exception e) => MessageBox.Show(this,e.Message,"작업을 완료할 수 없습니다",MessageBoxButtons.OK,MessageBoxIcon.Warning);
    bool Commit() { if (!Validate() || !grid.EndEdit()) return false; if (grid.DataSource != null) BindingContext?[grid.DataSource]?.EndCurrentEdit(); return true; }
    string State() => JsonSerializer.Serialize(doc);
    void Record() {
        if (loading || doc==null) return;
        var next=State(); if(next!=lastState) { undo.Push(lastState);redo.Clear();lastState=next; }
        UpdateStatus();
    }
    void UpdateStatus() {
        Text=$"{(lastState != savedState ? "* " : "")}{Path.GetFileName(filePath) ?? "파일을 열어 주세요"} — GDR2 프레임 편집기";
        status.Text=doc==null ? "GDR2 파일을 열거나 창으로 끌어 놓으세요." : $"{doc.LevelName}  |  {doc.Framerate:g} FPS  |  입력 {doc.Inputs.Count:N0}개 (P1 {doc.Inputs.Count(x=>!x.Player2):N0} / P2 {doc.Inputs.Count(x=>x.Player2):N0})  |  사망 {doc.Deaths.Count}개";
        timeline.Document=doc;timeline.Invalidate();
    }
    void Bind() {
        loading=true;
        try { grid.DataSource=null; properties.SelectedObject=doc; if(doc!=null) { grid.DataSource=new BindingList<ReplayInput>(doc.Inputs);grid.Columns["Button"].ReadOnly=!doc.Platformer; } }
        finally { loading=false; } UpdateStatus();
    }
    bool MayDiscard() {
        if (!Commit()) return false;
        Record(); if(doc==null || lastState==savedState)return true;
        var answer=MessageBox.Show(this,"변경 내용을 저장하시겠습니까?","저장하지 않은 변경",MessageBoxButtons.YesNoCancel,MessageBoxIcon.Question);
        if(answer==DialogResult.Cancel)return false;
        if(answer==DialogResult.Yes) { Save();return lastState==savedState; } return true;
    }
    void Open() { if(!MayDiscard())return;using var d=new OpenFileDialog{Filter="GDR2 리플레이|*.gdr2|모든 파일|*.*"};if(d.ShowDialog(this)==DialogResult.OK)LoadFile(d.FileName); }
    void LoadFile(string path) {
        try {
            if(new FileInfo(path).Length>64*1024*1024)throw new InvalidDataException("파일 크기 제한은 64 MB입니다.");
            var next=Replay.Read(File.ReadAllBytes(path));doc=next;filePath=path;undo.Clear();redo.Clear();lastState=savedState=State();Bind();
        } catch(Exception e) { Error(e); }
    }
    void Save() {
        if(doc==null || !Commit())return;
        using var d=new SaveFileDialog{Filter="GDR2 리플레이|*.gdr2",DefaultExt="gdr2",AddExtension=true,FileName=Path.GetFileNameWithoutExtension(filePath)+"_edited.gdr2",OverwritePrompt=true};
        if(d.ShowDialog(this)!=DialogResult.OK)return;
        try { doc.SaveAs(d.FileName);filePath=d.FileName;Record();savedState=lastState;UpdateStatus();status.Text="저장 완료 — "+d.FileName; }catch(Exception e){Error(e);}
    }
    ReplayInput[] Selected()=>grid.SelectedRows.Cast<DataGridViewRow>().Select(x=>x.DataBoundItem).OfType<ReplayInput>().ToArray();
    void Add() {
        if(doc==null || !Commit())return;
        if(doc.InputTag.Length>0){MessageBox.Show(this,"사용자 정의 입력 확장이 있는 파일은 새 입력 추가를 지원하지 않습니다. 기존 입력의 프레임은 수정할 수 있습니다.");return;}
        var current=Selected().FirstOrDefault();var row=new ReplayInput{Frame=current?.Frame??0,Player2=current?.Player2??false,Down=!(current?.Down??false)};
        doc.Inputs.Add(row);Bind();Record();foreach(DataGridViewRow r in grid.Rows)if(ReferenceEquals(r.DataBoundItem,row)){grid.ClearSelection();r.Selected=true;grid.CurrentCell=r.Cells[0];break;}
    }
    void Delete(){if(doc==null || !Commit())return;foreach(var row in Selected())doc.Inputs.Remove(row);Bind();Record();}
    void Shift(){if(doc==null || !Commit())return;try{var rows=Selected();if(rows.Length==0)return;doc.Shift(rows,(long)shift.Value);Bind();Record();}catch(Exception e){Error(e);}}
    void SortFrames(){if(doc==null || !Commit())return;doc.Inputs=doc.Inputs.OrderBy(x=>x.Frame).ToList();Bind();Record();}
    void Seek(){if(seek.Value<=ulong.MaxValue)GoTo((ulong)seek.Value);}
    void GoTo(ulong frame){if(doc==null || grid.Rows.Count==0 || !Commit())return;var row=grid.Rows.Cast<DataGridViewRow>().OrderBy(x=>Math.Abs((decimal)((ReplayInput)x.DataBoundItem).Frame-frame)).First();grid.ClearSelection();row.Selected=true;grid.CurrentCell=row.Cells[0];grid.FirstDisplayedScrollingRowIndex=row.Index;}
    void Undo(){if(doc==null || !Commit())return;Record();if(undo.Count==0)return;redo.Push(State());lastState=undo.Pop();doc=JsonSerializer.Deserialize<Replay>(lastState)!;Bind();}
    void Redo(){if(doc==null || !Commit())return;Record();if(redo.Count==0)return;undo.Push(State());lastState=redo.Pop();doc=JsonSerializer.Deserialize<Replay>(lastState)!;Bind();}
    void EditDeaths(){
        if(doc==null || !Commit())return;
        using var dialog=new Form{Text="사망 프레임 — 한 줄에 하나",Width=420,Height=450,StartPosition=FormStartPosition.CenterParent};
        var text=new TextBox{Multiline=true,Dock=DockStyle.Fill,ScrollBars=ScrollBars.Vertical,Text=string.Join(Environment.NewLine,doc.Deaths)};
        var apply=new Button{Text="적용",Dock=DockStyle.Bottom,Height=40};dialog.Controls.Add(text);dialog.Controls.Add(apply);
        apply.Click+=(_,_)=>{try{var deaths=text.Lines.Where(x=>!string.IsNullOrWhiteSpace(x)).Select(x=>ulong.Parse(x.Trim())).Order().ToList();doc.Deaths=deaths;Record();dialog.Close();}catch(Exception e){Error(e);}};
        dialog.ShowDialog(this);
    }
}

public sealed class Timeline : Control
{
    public Replay? Document {get;set;}
    public ulong? Selected {get;set;}
    public event Action<ulong>? Jump;
    public Timeline(){DoubleBuffered=true;BackColor=Color.FromArgb(27,34,48);ForeColor=Color.White;Cursor=Cursors.Hand;}
    protected override void OnPaint(PaintEventArgs e){
        base.OnPaint(e);var d=Document;if(d==null || d.Inputs.Count==0)return;
        ulong max=Math.Max(1UL,d.Inputs.Max(x=>x.Frame));
        using var p1=new Pen(Color.FromArgb(83,195,231));using var p2=new Pen(Color.FromArgb(238,164,87));using var selected=new Pen(Color.White,2);
        e.Graphics.DrawString("P1",Font,Brushes.White,5,16);e.Graphics.DrawString("P2",Font,Brushes.White,5,43);
        foreach(var input in d.Inputs){float x=40+(float)((double)input.Frame/max*Math.Max(1,Width-60));int y=input.Player2?47:20;e.Graphics.DrawLine(input.Player2?p2:p1,x,y,x,y+(input.Down?16:7));}
        if(Selected is ulong frame){float x=40+(float)((double)frame/max*Math.Max(1,Width-60));e.Graphics.DrawLine(selected,x,8,x,66);}
        e.Graphics.DrawString($"0 → {max:N0} 프레임 · 클릭하여 입력 선택",Font,Brushes.LightGray,40,70);
    }
    protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);if(Document?.Inputs.Count>0){ulong max=Document.Inputs.Max(x=>x.Frame);double ratio=Math.Clamp((e.X-40.0)/Math.Max(1,Width-60),0,1);Jump?.Invoke((ulong)((decimal)ratio*max));}}
}
