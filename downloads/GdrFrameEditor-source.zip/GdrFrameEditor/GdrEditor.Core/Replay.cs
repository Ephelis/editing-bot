using System.Buffers.Binary;
using System.ComponentModel;
using System.Text;

namespace GdrEditor.Core;

public sealed class ReplayInput
{
    public ulong Frame { get; set; }
    public int Button { get; set; } = 1;
    public bool Player2 { get; set; }
    public bool Down { get; set; } = true;
    [Browsable(false)] public byte[] Extension { get; set; } = [];
}

public sealed class Replay
{
    [ReadOnly(true), DisplayName("입력 확장 태그")] public string InputTag { get; set; } = "";
    [DisplayName("작성자")] public string Author { get; set; } = "";
    [DisplayName("설명")] public string Description { get; set; } = "";
    [DisplayName("길이 (초)")] public float Duration { get; set; }
    [DisplayName("게임 버전")] public int GameVersion { get; set; }
    [DisplayName("FPS / TPS")] public double Framerate { get; set; } = 240;
    [DisplayName("시드")] public int Seed { get; set; }
    [DisplayName("코인")] public int Coins { get; set; }
    [DisplayName("저사양 모드")] public bool Ldm { get; set; }
    [ReadOnly(true), DisplayName("플랫포머")] public bool Platformer { get; set; }
    [DisplayName("봇 이름")] public string BotName { get; set; } = "";
    [DisplayName("봇 버전")] public int BotVersion { get; set; }
    [DisplayName("레벨 ID")] public uint LevelId { get; set; }
    [DisplayName("레벨 이름")] public string LevelName { get; set; } = "";
    [Browsable(false)] public byte[] Extension { get; set; } = [];
    [Browsable(false)] public List<ulong> Deaths { get; set; } = [];
    [Browsable(false)] public List<ReplayInput> Inputs { get; set; } = [];

    public void Shift(IEnumerable<ReplayInput> selected, long offset)
    {
        var rows = selected.Distinct().ToArray();
        var next = rows.Select(x => offset >= 0 ? checked(x.Frame + (ulong)offset)
            : checked(x.Frame - (ulong)(-(offset + 1)) - 1)).ToArray();
        int bits = Platformer ? 3 : 1;
        if (next.Any(x => x > (ulong.MaxValue >> bits))) throw new InvalidDataException("프레임 범위를 초과합니다.");
        for (int i = 0; i < rows.Length; i++) rows[i].Frame = next[i];
    }

    public static Replay Read(byte[] bytes)
    {
        if (bytes.Length > 64 * 1024 * 1024) throw new InvalidDataException("파일 크기 제한은 64 MB입니다.");
        var r = new Reader(bytes);
        if (!r.Raw(3).SequenceEqual("GDR"u8.ToArray()) || r.Var() != 2)
            throw new InvalidDataException("GDR 버전 2 파일만 지원합니다.");
        var d = new Replay {
            InputTag = r.String(), Author = r.String(), Description = r.String(),
            Duration = BitConverter.Int32BitsToSingle(BinaryPrimitives.ReadInt32BigEndian(r.Raw(4))),
            GameVersion = unchecked((int)r.Var()),
            Framerate = BitConverter.Int64BitsToDouble(BinaryPrimitives.ReadInt64BigEndian(r.Raw(8))),
            Seed = unchecked((int)r.Var()), Coins = unchecked((int)r.Var()), Ldm = r.Bool(), Platformer = r.Bool(),
            BotName = r.String(), BotVersion = unchecked((int)r.Var()), LevelId = checked((uint)r.Var()), LevelName = r.String(),
            Extension = r.Block()
        };
        var count = r.Count(); ulong previous = 0;
        for (int i = 0; i < count; i++) { previous = checked(previous + r.Var()); d.Deaths.Add(previous); }
        count = r.Count(); int p1 = r.Count();
        if (p1 > count) throw new InvalidDataException("P1 입력 개수가 잘못되었습니다.");
        previous = 0;
        for (int i = 0; i < count; i++) {
            if (i == p1) previous = 0;
            ulong packed = r.Var(); previous = checked(previous + (packed >> (d.Platformer ? 3 : 1)));
            d.Inputs.Add(new() { Frame = previous, Button = d.Platformer ? (int)((packed >> 1) & 3) : 1,
                Down = (packed & 1) != 0, Player2 = i >= p1, Extension = d.InputTag.Length > 0 ? r.Block() : [] });
        }
        if (!r.AtEnd) throw new InvalidDataException("인식할 수 없는 후행 데이터가 있습니다. 손실 방지를 위해 열기를 중단했습니다.");
        d.Inputs = d.Inputs.OrderBy(x => x.Frame).ToList();
        return d;
    }

    public byte[] Write()
    {
        if (!double.IsFinite(Framerate) || Framerate <= 0 || !float.IsFinite(Duration) || Duration < 0)
            throw new InvalidDataException("FPS는 0보다 커야 하며 길이는 0 이상이어야 합니다.");
        using var s = new MemoryStream();
        void Var(ulong n) { do { byte b = (byte)(n & 127); n >>= 7; s.WriteByte((byte)(b | (n > 0 ? 128 : 0))); } while (n != 0); }
        void Block(byte[] data) { Var((ulong)data.Length); s.Write(data); }
        void Str(string value) { var data = Encoding.UTF8.GetBytes(value); if (data.Length > 65535) throw new InvalidDataException("문자열이 너무 깁니다."); Block(data); }
        void Int(int n) => Var(unchecked((ulong)(long)n));
        s.Write("GDR"u8); Var(2); Str(InputTag); Str(Author); Str(Description);
        var numeric = new byte[8]; BinaryPrimitives.WriteSingleBigEndian(numeric, Duration); s.Write(numeric,0,4); Int(GameVersion);
        BinaryPrimitives.WriteDoubleBigEndian(numeric, Framerate); s.Write(numeric); Int(Seed); Int(Coins);
        Var(Ldm ? 1UL : 0); Var(Platformer ? 1UL : 0); Str(BotName); Int(BotVersion); Var(LevelId); Str(LevelName); Block(Extension);
        Var((ulong)Deaths.Count); ulong p = 0;
        foreach (var frame in Deaths.Order()) { Var(frame - p); p = frame; }
        Var((ulong)Inputs.Count); Var((ulong)Inputs.Count(x => !x.Player2));
        foreach (bool player2 in new[] { false, true }) {
            p = 0;
            foreach (var x in Inputs.Where(x => x.Player2 == player2).OrderBy(x => x.Frame)) {
                int bits = Platformer ? 3 : 1;
                if (x.Button < 0 || x.Button > 3 || (!Platformer && x.Button != 1))
                    throw new InvalidDataException("일반 모드는 점프(1)만 지원합니다. 플랫포머 버튼은 0~3입니다.");
                if (x.Frame - p > (ulong.MaxValue >> bits)) throw new InvalidDataException("프레임 차이가 너무 큽니다.");
                Var(((x.Frame - p) << bits) | (Platformer ? (ulong)x.Button << 1 : 0) | (x.Down ? 1UL : 0));
                if (InputTag.Length > 0) Block(x.Extension);
                else if (x.Extension.Length != 0) throw new InvalidDataException("확장 태그가 없는 입력에 확장 데이터가 있습니다.");
                p = x.Frame;
            }
        }
        return s.ToArray();
    }

    public void SaveAs(string path)
    {
        byte[] bytes = Write(); _ = Read(bytes);
        string full = Path.GetFullPath(path), temp = full + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try {
            using (var file = new FileStream(temp, FileMode.CreateNew, FileAccess.Write)) { file.Write(bytes); file.Flush(true); }
            if (File.Exists(full)) File.Replace(temp, full, full + "." + DateTime.UtcNow.ToString("yyyyMMddHHmmssfff") + ".bak");
            else File.Move(temp, full);
        } finally { if (File.Exists(temp)) File.Delete(temp); }
    }

    private sealed class Reader(byte[] data)
    {
        int pos;
        public bool AtEnd => pos == data.Length;
        public byte[] Raw(int count) {
            if (count < 0 || count > data.Length - pos) throw new InvalidDataException("파일이 잘렸거나 데이터 길이가 잘못되었습니다.");
            byte[] result = data.AsSpan(pos,count).ToArray(); pos += count; return result;
        }
        public ulong Var() {
            ulong value = 0;
            for (int i = 0; i < 10; i++) {
                if (pos == data.Length) throw new InvalidDataException("가변 정수가 잘렸습니다.");
                byte b = data[pos++];
                if (i == 9 && b > 1) throw new InvalidDataException("가변 정수 오버플로입니다.");
                value |= (ulong)(b & 127) << (i * 7);
                if (b < 128) return value;
            }
            throw new InvalidDataException("잘못된 가변 정수입니다.");
        }
        public bool Bool() { var n = Var(); return n <= 1 ? n == 1 : throw new InvalidDataException("잘못된 bool 값입니다."); }
        public int Count() { ulong n = Var(); return n <= 2_000_000 && n <= (ulong)(data.Length - pos) ? (int)n : throw new InvalidDataException("데이터 개수가 잘못되었습니다."); }
        public byte[] Block() { ulong n = Var(); if (n > (ulong)(data.Length-pos)) throw new InvalidDataException("확장 길이가 잘못되었습니다."); return Raw((int)n); }
        public string String() { var b = Block(); if (b.Length > 65535) throw new InvalidDataException("문자열이 너무 깁니다."); return new UTF8Encoding(false,true).GetString(b); }
    }
}
